#ifndef CMD_CLI_SPI_H
#define CMD_CLI_SPI_H

#include "autoconf.h"

#if CONFIG_ENABLE_CLI_SPI_COMMAND

void CMD_SPI_init(void);

#endif /* CONFIG_ENABLE_CLI_SPI_COMMAND */
#endif /* CMD_CLI_SPI_H */
