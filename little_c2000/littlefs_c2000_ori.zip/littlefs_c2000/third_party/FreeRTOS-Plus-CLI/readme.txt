Contains source and header files that implement FreeRTOS+CLI.  See
http://www.FreeRTOS.org/cli for documentation and license information.

 