#ifndef CMD_CLI_FM25W256_H
#define CMD_CLI_FM25W256_H

#include "autoconf.h"

#if CONFIG_ENABLE_CLI_FM25W256_COMMAND

void CMD_FM25W256_init(void);

#endif /* CONFIG_ENABLE_CLI_FM25W256_COMMAND */
#endif /* CMD_CLI_FM25W256_H */
